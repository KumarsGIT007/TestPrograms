from ExpenditureBanking.Methods import login

if login.login_token() is None:
    print("Login FAILED")
else:
    print("Login Successful")
