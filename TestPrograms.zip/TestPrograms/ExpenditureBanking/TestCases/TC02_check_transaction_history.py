from ExpenditureBanking.Methods import transactions
from ExpenditureBanking.Methods import login

token = login.login_token()
transactions.transactions(token)
