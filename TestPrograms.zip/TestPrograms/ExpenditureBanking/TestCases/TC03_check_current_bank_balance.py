from ExpenditureBanking.Methods import balance
from ExpenditureBanking.Methods import login

token = login.login_token()
current_balance = balance.check_balance(token)
print("Your current balance is", current_balance['balance'])
