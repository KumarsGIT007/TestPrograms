from ExpenditureBanking.Methods import login
from ExpenditureBanking.Methods import spend
from ExpenditureBanking.Methods import balance


token = login.login_token()
current_balance = balance.check_balance(token)
print("Your current balance is", current_balance['balance'])
item_description = input("Enter the short description of the item purchased : ")
amount = int(input("Enter the amount spent on the item purchased : "))


if amount <= int(current_balance['balance']):
    print("After buying " + item_description + " for " + str(amount) + "GBP ...")
    spend.spend(token, item_description, amount)
    current_balance = balance.check_balance(token)
    print("Your balance after last expenditure is", current_balance['balance'])
else:
    raise Exception("The entered amount is greater than available balance")


