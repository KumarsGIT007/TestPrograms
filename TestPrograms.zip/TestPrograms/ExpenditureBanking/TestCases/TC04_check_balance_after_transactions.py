from ExpenditureBanking.Methods import login
from ExpenditureBanking.Methods import spend
from ExpenditureBanking.Methods import balance


token = login.login_token()
current_balance = balance.check_balance(token)
print("Your current balance is", current_balance['balance'])
item_description = input("Enter the short description of the item purchased : ")
amount = input("Enter the amount spent on the item purchased : ")
print("After buying " + item_description + " for " + amount + "GBP ...")
spend.spend(token, item_description, amount)
current_balance = balance.check_balance(token)
print("Your balance after last expenditure is", current_balance['balance'])

