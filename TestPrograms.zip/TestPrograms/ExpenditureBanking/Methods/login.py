import requests
from ExpenditureBanking.Methods import get_baseurl


def login_token():
    endpoint = '/login'
    header_info = {"Accept": "application/json",
                   "Content-Type": "application/json"
                   }
    url_data = get_baseurl.base_url() + endpoint
    # Do a POST call for getting Login token
    response_json = (requests.post(url=url_data, data=None, headers=header_info)).json()
    return response_json['token']

