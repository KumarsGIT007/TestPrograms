import requests
from ExpenditureBanking.Methods import get_baseurl


def transactions(token):
    endpoint = '/transactions'
    header_info = {"Accept": "application/json",
                   "Content-Type": "application/json",
                   "Authorization": "Bearer" + " " + token
                   }
    url_data = get_baseurl.base_url() + endpoint
    # Do a GET call for getting transactions details
    response_json = (requests.get(url=url_data, headers=header_info)).json()
    print(response_json)
