import requests
import json
from datetime import datetime
from ExpenditureBanking.Methods import get_baseurl


def spend(token, item, amount):
    endpoint = '/spend'
    header_info = {"Accept": "application/json",
                   "Content-Type": "application/json",
                   "Authorization": "Bearer" + " " + token
                   }
    # form the complete endpoint url
    url_data = get_baseurl.base_url() + endpoint
    # get current date and time
    now = datetime.now()
    date_string = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    # form request dictionary
    req_dict = {
        "date": date_string,
        "description": item,
        "amount": amount,
        "currency": "GBP"
    }
    # convert request dictionary to JSON format
    req_json = json.dumps(req_dict)
    # Do a POST call for buying an item
    response_json = (requests.post(url=url_data, data=req_json, headers=header_info))
    return response_json

