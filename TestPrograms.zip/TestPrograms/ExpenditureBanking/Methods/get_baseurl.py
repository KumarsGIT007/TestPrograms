import json


def base_url():
    with open('C:/Users/JU4X/IdeaProjects/TestPrograms/ExpenditureBanking/Config/config.json', 'r') as cf:
        config_json = json.load(cf)
        protocol = config_json['protocol']
        host = config_json['host']
    # form the URL
    b_url = protocol + "://" + host
    return b_url
