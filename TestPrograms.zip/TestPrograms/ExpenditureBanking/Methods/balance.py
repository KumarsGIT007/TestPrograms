import requests
from ExpenditureBanking.Methods import get_baseurl
from ExpenditureBanking.Methods import login


def check_balance(token):
    endpoint = '/balance'
    header_info = {"Accept": "application/json",
                   "Content-Type": "application/json",
                   "Authorization": "Bearer" + " " + token
                   }
    url_data = get_baseurl.base_url() + endpoint
    # Do a GET call for getting transactions details
    response_json = (requests.get(url=url_data, headers=header_info)).json()
    return response_json
