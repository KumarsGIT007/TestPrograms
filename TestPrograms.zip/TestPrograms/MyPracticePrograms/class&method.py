class InputOutput:
    def getstring(self):
        str1 = input("Enter a string to display: ")
        return str1

    def printstring(self, str2):
        print ("Input string is: ", str2.upper())


'Test functions for class'
io = InputOutput()
str3 = io.getstring()
io.printstring(str3)