no_of_transactions = int(input("Enter number of transactions to log (only +ve numeric input accepted): "))
transactions = ""
print("Enter the transactions below - For Deposit as (D<space>Amount) & For Withdrawal as (W<space>Amount): ")
# take multiple transactions input from user
for i in range(no_of_transactions):
    transactions += input() + "\n"
new_transactions = transactions.split("\n")
# Declare transaction variables
deposit = 0
withdrawal = 0
net_amount = 0
for x in new_transactions:
    if x.startswith('D'):  # Identify Deposits
        deposit += int(x.lstrip("D "))  # Sum up deposits
    elif x.startswith('W'):  # Identify Withdrawal
        withdrawal += int(x.lstrip("W "))  # Sum up withdrawals
print("Total Deposit: INR ", deposit)
print("Total Withdrawal: INR ", withdrawal)
net_amount = deposit-withdrawal  # Net amount calculation
print("Current Amount in bank is INR ", net_amount)



