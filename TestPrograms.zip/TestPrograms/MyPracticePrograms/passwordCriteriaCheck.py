import re


def password_criteria_check(password):  # function to check the password criteria
    if re.findall("[a-z]", password) and re.findall("[A-Z]", password) and re.findall("[0-9]", password) \
            and re.findall("[$#@]", password) and 6 <= len(password) <= 12:
        return password
    else:
        return 0


password_str = input("Enter sequence of password in comma-separated format: ")
password_list = password_str.split(",")
accepted_passwords = []
#  Find list of all accepted passwords
for x in password_list:
    if password_criteria_check(x) != 0:
        accepted_passwords.append(x)
print("Validated passwords are: ")
for i in accepted_passwords:  # print accepted passwords in comma separated format
    if i == accepted_passwords[len(accepted_passwords) - 1]:
        print(i)
    else:
        print(i, end=",")