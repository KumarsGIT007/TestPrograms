class Student:
    marks = 0.0
    age = 0

    def __init__(self, name, roll_number):
        self.name = name
        self.roll_number = roll_number

    def display_info(self):
        print("Name:", self.name)
        print("Age : ", self.age)
        print("RollNumber: ", self.roll_number)
        print("Marks :", self.marks)
        print('\n')

    def set_marks(self, input_marks):
        self.marks = input_marks

    def set_age(self, input_age):
        self.age = input_age


s1 = Student('Kumar', 7)
#s1.set_marks(100)
s1.set_age(30)
s1.display_info()

s2 = Student('TituMama', 1)
s2.set_age(60)
s2.set_marks(33.5)
s2.display_info()