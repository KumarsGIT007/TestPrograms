def factorial(n):  # define a recursive function to calculate factorial of a number
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)


num = int(input("Enter a number to find its factorial: "))
# print the factorial of the given number by calling the function created to calculate factorial
print("Factorial is: ", factorial(num))