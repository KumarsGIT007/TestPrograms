input_string = input("Enter a string sequence for which word occurrence needs to be calculated: ")
list1 = input_string.split(' ')  # remove whitespaces from the provided string and store it in a list
list1.sort()  # sort the list alphanumerically

count = 0
final_dict = {}
for x in list1:
    final_dict[x] = list1.count(x)
for x in final_dict:
    print(x, ':', final_dict[x])
