import math


def displacement_calculator(list1):
    up, down, left, right, horizontal, vertical, displacement = 0, 0, 0, 0, 0, 0, 0
    for i in range(4):
        if list1[i].startswith('U') or list1[i].startswith('u'):
            up = int(list1[i].lstrip("UPup "))
        elif list1[i].startswith('D') or list1[i].startswith('d'):
            down = int(list1[i].lstrip("DOWNdown "))
        elif list1[i].startswith('L') or list1[i].startswith('l'):
            left = int(list1[i].lstrip("LEFTleft "))
        elif list1[i].startswith('R') or list1[i].startswith('r'):
            right = int(list1[i].lstrip("RIGHTright "))

    horizontal = left - right
    vertical = up - down
    displacement = float(math.sqrt(horizontal**2 + vertical**2))
    return round(displacement)


def get_robot_movement():
    movement = ''
    for i in range(4):
        movement += input() + "\n"
    temp_list = movement.split('\n')
    return temp_list


print("""Enter the movement of the robot from its ORIGIN (0,0) position as below format:
*********************
UP <dist> or blank
DOWN <dist> or blank
RIGHT <dist> or blank
LEFT <dist> or blank
**********************""")
movement_list = get_robot_movement()
distance_covered = displacement_calculator(movement_list)
print("Distance covered by robot from its original position (0,0) is : ", distance_covered)

