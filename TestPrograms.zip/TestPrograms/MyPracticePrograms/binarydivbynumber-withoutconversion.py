# take user input of binary numbers in comma separated format
temp = input("Enter a sequence of comma-separated 4-digit binary numbers : ")
# remove the commas from the input and put it in a list
binary_list = temp.split(',')
# declare divisible by 5 decimal list
div_by_five = []
five = 101  # binary representation of 5
for b in binary_list:
    b = int(b)  # convert the str binary to int representation
    if b % five == 0:  # check if number is divisible by 5
        div_by_five.append(b)  # list of numbers divisible by 5
for d in div_by_five:
    if d == div_by_five[len(div_by_five) - 1]:
        print(d)
    else:
        print(d, end=',')