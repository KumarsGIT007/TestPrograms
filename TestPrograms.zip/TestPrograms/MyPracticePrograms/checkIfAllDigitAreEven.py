num1 = 1000
num2 = 3000
result = []
for n in range(num1, num2 + 1):
    str1 = str(n)
    if int(str1[0]) % 2 == 0 and int(str1[1]) % 2 == 0 and int(str1[2]) % 2 == 0 and int(str1[3]) % 2 == 0:
        result.append(str1)
for n in result:
    if n == result[len(result) - 1]:
        print(n)
    else:
        print(n, end=',')