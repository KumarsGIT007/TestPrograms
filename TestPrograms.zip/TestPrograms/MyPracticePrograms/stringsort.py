str1 = input("Enter a series of words comma-separated :")
# remove the commas from the input sequence
words = str1.split(',')
# sort the word sequence after removing the commas
words.sort()
print("Sorted words in alphabetical order are: ")
# print the sorted result in a comma-separated manner
for i in words:
    if i == words[len(words)-1]:
        print(i)
    else:
        print(i, end=',')

