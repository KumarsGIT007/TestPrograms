new_list =[] # A list which holds the numbers
num1 = 1000
num2 = 3000
for a in range(num1, num2 + 1):
    for b in str(a):
        if int(b) % 2 == 1:
            break
    else:  # this block is executed only when loop doesn't break
        new_list.append(a)
# print result in comma-separated sequence
for n in new_list:
    if n == new_list[len(new_list) - 1]:
        print(n)
    else:
        print(n, end=',')