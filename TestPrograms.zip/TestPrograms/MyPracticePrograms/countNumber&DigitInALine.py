str1 = input("Enter a sentence containing both alphabets and numeric digits : ")
digits = 0
letters = 0
for i in str1:
    if i.isdigit():  # check is the element of str is a digit
        digits += 1
    elif i.isalpha():  # check is the element of str is a letter
        letters += 1
print(" LETTERS ", letters, "\n", "DIGITS ", digits)