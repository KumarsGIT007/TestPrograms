str1 = ""
nol = int(input("Enter number of lines to input (only +ve numeric input accepted): "))
print("Enter your sequence of %i lines below: " % nol)
# take multiple line input from user
for i in range(nol):
    str1 += input() + "\n"
# print multiple line input from user in UPPERCASE
print(str1.upper())
