str1 = input("Enter a series of words(may contain duplicates) whitespace-separated :")
words = str1.split(' ')
# convert the sequence of words to a dictionary as dictionary removes all duplicates
dict1 = dict.fromkeys(words)
# convert the dictionary back to list by type casting
words = list(dict1)
# sort the list of words for which duplicates are removed
words.sort()
for x in words:
    if x == words[len(words) - 1]:
        print(x)
    else:
        print(x, end=" ")
