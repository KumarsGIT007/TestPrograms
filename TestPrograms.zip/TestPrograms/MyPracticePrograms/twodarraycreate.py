X = int(input("Enter number of rows :"))
Y = int(input("Enter number of columns :"))
# declare final array
final_array = []
for i in range(0, X):  # run through the rows
    # for each row create the initial blank column values
    col = []
    for j in range(0, Y):  # run through the columns
        # generate the column values and insert in the column list
        col.append(i*j)
    # insert the column wise values in each row
    final_array.append(col)
# print the final 2-D array
print("The final 2-D array is : ", final_array)
