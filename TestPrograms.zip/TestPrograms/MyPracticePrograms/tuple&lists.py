values = input("Enter a number sequence in comma-separated format:")

num = values.split(',')
print("List is: ", num)
print("Tuple is: ", tuple(num))

