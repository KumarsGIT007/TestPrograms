num1 = 2000
num2 = 3200

# Method1
numlist1 = []
while num1 <= num2:
    if num1 % 7 == 0 and num1 % 5 != 0:
        numlist1.append(num1)
    num1 += 1

for num in numlist1:
    if num == numlist1[len(numlist1) - 1]:
        print(num)
    else:
        print(num, end=',')

