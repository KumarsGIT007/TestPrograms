class Time:

    def __init__(self, hours, minutes):
        self.hours = hours
        self.minutes = minutes

    def add_time(self, t1, t2):

        if (t1.minutes + t2.minutes) > 59:
            self.minutes = (t1.minutes + t2.minutes) % 60
            self.hours = t1.hours + t2.hours + (t1.minutes + t2.minutes) // 60
        else:
            self.minutes = t1.minutes + t2.minutes
            self.hours = t1.hours + t2.hours

        return Time(self.hours, self.minutes)

    def display_time(self):
        print("Total time is: ", self.hours, "hours & ", self.minutes, "minutes")

    def display_minutes(self):
        self.minutes = self.minutes + self.hours * 60
        print("Total time in minutes: ", self.minutes, "mins")


time1 = Time(2, 50)
time2 = Time(1, 20)
# declare result object
res = Time(0,0)
# Call add_time method
res.add_time(time1, time2)
# Display added time
res.display_time()
# display time in minutes
res.display_minutes()
time1.display_minutes()