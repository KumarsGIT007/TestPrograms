num = int(input("Enter the maximum number to build the number and its square dictionary: "))
# declare an empty dictionary
dict1 = {}
for x in range(1, num+1):
    # create the key value pair of the number and its square and store in the dictionary
    dict1[x] = x*x
print("The Number and its square dictionary is: ", dict1)