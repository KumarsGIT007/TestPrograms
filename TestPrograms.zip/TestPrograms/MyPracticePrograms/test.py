import math

str1 = ''
print("Enter the robots movement as below: ")
for i in range(4):
    str1 += input() + "\n"
list1 = str1.split('\n')

horizontal = 0
vertical = 0
up = 0
down = 0
left = 0
right = 0
displacement = 0.0


for i in range(4):
    if list1[i].startswith('U') or list1[i].startswith('u'):
        up = int(list1[i].lstrip("UPup "))
    elif list1[i].startswith('D') or list1[i].startswith('d'):
        down = int(list1[i].lstrip("DOWNdown "))
    elif list1[i].startswith('L') or list1[i].startswith('l'):
        left = int(list1[i].lstrip("LEFTleft "))
    elif list1[i].startswith('R') or list1[i].startswith('r'):
        right = int(list1[i].lstrip("RIGHTright "))

horizontal = left - right
vertical = up - down
displacement = float(math.sqrt(horizontal**2 + vertical**2))
print(round(displacement))

