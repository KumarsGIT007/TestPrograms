class CircleArea:

    def __init__(self, radius):
        self.radius = radius

    def get_area(self):
        area = round((22/7 * self.radius**2), 2)
        print("Area of the circle is: ", area)

    def get_circumference(self):
        circumference = round((2 * 22/7 * self.radius), 2)
        print("Circumference of the circle is : ", circumference)


radius_input = int(input("Enter the radius value for the circle: "))
circle = CircleArea(radius_input)
circle.get_area()
circle.get_circumference()

