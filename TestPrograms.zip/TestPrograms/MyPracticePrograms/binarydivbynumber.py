# take user input of binary numbers in comma separated format
temp = input("Enter a sequence of comma-separated 4-digit binary numbers : ")
# remove the commas from the input and put it in a list
binary_list = temp.split(',')
# create blank decimal list
decimal_list = []
# divisible by 5 decimal list
div_by_five = []
# convert each member in the list binary to decimal
for b in binary_list:
    decimal_list.append(int(b, 2))  # int(b, 2) converts binary to decimal
# print the decimal list
for d in decimal_list:
    if d % 5 == 0:
        div_by_five.append(d)  # decimal list of numbers divisible by 5
bin1 = []  # empty list to store binary list fo numbers divisible by 5
for div in div_by_five:
    bin1.append(bin(div)[2:])  # bin(div) converts decimal to binary and [2:] trims the '0b' from the conversion list
# print the div by 5 list
for i in bin1:
    if i == bin1[len(bin1) - 1]:
        print(i)
    else:
        print(i, end=',')